<!DOCTYPE html>
<html>
<head>
<title>Cyberstore</title>
<link rel="icon" href="img/logo.png">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" type="text/css" href="test.css" />
<link rel="stylesheet" type="text/css" href="test3.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js">
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></script>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

<style>
  
  body {
    font-family: Arial, Helvetica, sans-serif;
    margin: 0;
    background: #2a2e32;
  }
  a {
    color: inherit;
    text-decoration: none;
    transition: all 0.3s;
  }
  
  a:hover, a:focus {
    text-decoration: none;
  }
  
  .form-control {
    background: #212529;
    border-color: #545454;
  }
  
  .form-control:focus {
    background: #212529;
  }
  
  footer {
    background: #2a2e32;
  }
  
  </style>
</head>
<body>
<div id="navdiv">
<div id="logo-div">
<a href="index.html"><img id="logo" src="img/logo.png"></a>
</div>
<div id="nav-items">
<ul id="navbar">
<li><a href="index.html">Home</a></li>
<li><a href="ourproducts.html">Our Products</a></li>
<li><a href="contactus.html">Contact Us</a></li>
<li><a href="newreleases.html">New Releases</a></li>
<li id="more">More <i id="caret-icon" class="fas fa-caret-down"></i>
<ul id="dropdown">

<li> <a href="members.html">Members</a></li>
<li><a href="aboutus.html">About Us</a></li>
<li class="current"><a href="Login.html">Sign Up or Login</a></li>
</ul>
</li>
</ul>
</div>
</div>
<div id="contents">
<div id="description">
<?php
$b=$_POST["password"];
$c=$_POST["password2"];
if($b!=$c)
echo"Your passwords don't match";
else
echo"Thank you for signing up!";
?>
</div>
<div class="container10">
  
<?php
//if($_SERVER['REQUEST_METHOD']=='post'&& isset ($_post['submit']))
//{
  echo "first condition ok";
  $conn=mysqli_connect('localhost','root','Mohammad12','signup') or
  die("connection failed:" .mysqli_connect_error());
  //if(isset($_post['firstname'])&&(isset($_post['lastname']) && (isset($_post['email'])&& (isset($_post['maildomain']) && (isset($_post['password']) && (isset($_post['password2'])))))))
//{
 // echo "<br> Isset ok <br>";
$x=$_POST["firstname"];
$y=$_POST["lastname"];
$z=$_POST["email"];
$a=$_POST["maildomain"];
$b=$_POST["password"];
$c=$_POST["password2"];



$sql="INSERT INTO `signupp` (`firstname`,`lastname`,`email`,`password`)
VALUES('$x','$y','$z$a','$b')";
if(mysqli_query($conn,$sql))
{header("location:login.html");}
else {echo "An Error Occured";}
mysqli_close($conn);

//}
//}

?>

</div>
</div>
</div>




</body>
<footer class="w-100 py-4 flex-shrink-0">
  <div class="container3">
      <div class="row gy-4 gx-5">
          <div class="col-lg-4 col-md-6">
              <h5 class="h1 text-white">Cyberstore</h5>
              <p  class="small text-muted">The world's leading online electronic store.</p>
              <p class="small text-muted mb-0">&copy; Copyrights. All rights reserved.</p>

              <div id="social-icons">
                <a href="https://www.facebook.com/Cyberstore-104422358222336" target="_blank"><i class="fab fa-facebook-square"></i></a>
                <a href="https://www.instagram.com/cyberstore_egy/" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://www.twitter.com/Cyberstore15" target="_blank"><i class="fab fa-twitter-square"></i></a>
                </div>
          </div>
          <div class="col-lg-2 col-md-6">
              <h5 class="text-white mb-3">Quick links</h5>
              <ul class="list-unstyled text-muted">
                  <li><a href="index.html">Home</a>
                  <li><a href="aboutus.html">About Us</a></li>
                  <li><a href="contactus.html">Contact Us</a></li>
                  <li><a href="newreleases.html">New Releases</a></li>
              </ul>
          </div>
          <div class="col-lg-2 col-md-6">
              <h5 class="text-white mb-3"></h5>
              <ul class="list-unstyled text-muted">
                <li><a href="#"></a></li>
                  <li><a href="#"></a></li>
                  <li><a href="#"></a></li>
                  <li><a href="#"></a></li>
              </ul>
          </div>
          <div class="col-lg-4 col-md-6">
              <h5 class="text-white mb-3">Inquries</h5>
              <p class="small text-muted">Contact us by typing your e-mail down below for further assistance.</p>
              <form action="#">
                  <div class="input-group mb-3">
                      <input class="form-control" type="text" placeholder="E-mail" aria-label="E-mail" aria-describedby="button-addon2">
                      <button class="btn btn-primary" id="button-addon2" type="button"><i class="fas fa-paper-plane"></i></button>
                  </div>
              </form>
          </div>
      </div>
  </div>
</footer>
<script>
const moreBtn = document.getElementById("more");
const caretIcon = document.getElementById("caret-icon");
moreBtn.addEventListener("mouseenter", () => {
caretIcon.classList = "fas fa-caret-up";
});
moreBtn.addEventListener("mouseleave", () => {
caretIcon.classList = "fas fa-caret-down";
});

var responsiveSlider = function() {

var slider = document.getElementById("slider");
var sliderWidth = slider.offsetWidth;
var slideList = document.getElementById("slideWrap");
var count = 1;
var items = slideList.querySelectorAll("li").length;
var prev = document.getElementById("prev");
var next = document.getElementById("next");

window.addEventListener('resize', function() {
  sliderWidth = slider.offsetWidth;
});

var prevSlide = function() {
  if(count > 1) {
    count = count - 2;
    slideList.style.left = "-" + count * sliderWidth + "px";
    count++;
  }
  else if(count = 1) {
    count = items - 1;
    slideList.style.left = "-" + count * sliderWidth + "px";
    count++;
  }
};

var nextSlide = function() {
  if(count < items) {
    slideList.style.left = "-" + count * sliderWidth + "px";
    count++;
  }
  else if(count = items) {
    slideList.style.left = "0px";
    count = 1;
  }
};

next.addEventListener("click", function() {
  nextSlide();
});

prev.addEventListener("click", function() {
  prevSlide();
});

setInterval(function() {
  nextSlide()
}, 5000);

};

window.onload = function() {
responsiveSlider();  
}



</script>
</body>
</html>